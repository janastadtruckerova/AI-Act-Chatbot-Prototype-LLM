
import { GoogleGenAI, Chat, GenerateContentResponse } from "@google/genai";

let chat: Chat | null = null;

const SYSTEM_INSTRUCTION = `You are an expert on the European Union's AI Act. Your role is to answer questions accurately and concisely based on the regulations and principles of the AI Act. Provide clear explanations and cite specific articles or sections when possible. Your answers must be in Slovak. Do not speculate or provide legal advice.`;

const getChatInstance = (): Chat => {
  if (!chat) {
    if (!process.env.API_KEY) {
      throw new Error("API_KEY environment variable not set.");
    }
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    chat = ai.chats.create({
      model: 'gemini-2.5-flash',
      config: {
        systemInstruction: SYSTEM_INSTRUCTION,
      },
    });
  }
  return chat;
};

export const getChatbotResponse = async (message: string): Promise<string> => {
  try {
    const chatInstance = getChatInstance();
    const response: GenerateContentResponse = await chatInstance.sendMessage({ message });
    return response.text;
  } catch (error) {
    console.error("Error getting response from Gemini API:", error);
    chat = null; // Reset chat on error
    return "Ospravedlňujeme sa, vyskytla sa chyba pri komunikácii s AI. Skúste to prosím znova neskôr.";
  }
};
