
import React, { useState, useCallback } from 'react';
import { ChatMessage, Role } from './types';
import { getChatbotResponse } from './services/geminiService';
import Header from './components/Header';
import ChatHistory from './components/ChatHistory';
import ChatInput from './components/ChatInput';

const App: React.FC = () => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      role: Role.MODEL,
      text: 'Dobrý deň! Som váš asistent pre AI Act. Ako vám dnes môžem pomôcť?'
    }
  ]);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const handleSendMessage = useCallback(async (userMessage: string) => {
    setError(null);
    setIsLoading(true);
    
    const newUserMessage: ChatMessage = { role: Role.USER, text: userMessage };
    setMessages(prevMessages => [...prevMessages, newUserMessage]);

    try {
      const botResponseText = await getChatbotResponse(userMessage);
      const newBotMessage: ChatMessage = { role: Role.MODEL, text: botResponseText };
      setMessages(prevMessages => [...prevMessages, newBotMessage]);
    } catch (e) {
      const errorMessage = e instanceof Error ? e.message : 'An unknown error occurred.';
      setError(errorMessage);
      const errorBotMessage: ChatMessage = { 
        role: Role.MODEL, 
        text: "Prepáčte, mám problém. Skúste obnoviť stránku alebo to skúste znova neskôr." 
      };
      setMessages(prevMessages => [...prevMessages, errorBotMessage]);
    } finally {
      setIsLoading(false);
    }
  }, []);

  return (
    <div className="flex flex-col h-screen bg-slate-900 text-white font-sans">
      <Header />
      <main className="flex-1 flex flex-col overflow-hidden">
        <ChatHistory messages={messages} isLoading={isLoading} />
        {error && (
          <div className="p-4 bg-red-800 text-center text-white text-sm">
            Chyba: {error}
          </div>
        )}
        <ChatInput onSendMessage={handleSendMessage} isLoading={isLoading} />
      </main>
    </div>
  );
};

export default App;
